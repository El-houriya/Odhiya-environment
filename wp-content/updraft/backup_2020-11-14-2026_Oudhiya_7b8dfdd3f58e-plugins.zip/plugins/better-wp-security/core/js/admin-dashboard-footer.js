if ( typeof postboxes !== 'undefined' ) {
	postboxes.add_postbox_toggles( pagenow );
}
