<?php

namespace iThemesSecurity\Ban_Hosts;

use iThemesSecurity\Exception\Invalid_Argument_Exception;

final class Unknown_Source extends Invalid_Argument_Exception {

}
