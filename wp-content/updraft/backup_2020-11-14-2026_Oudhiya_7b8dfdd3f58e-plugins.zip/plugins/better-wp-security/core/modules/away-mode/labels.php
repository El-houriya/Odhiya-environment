<?php

return [
	'title' => __( 'Away Mode', 'better-wp-security' ),
];
