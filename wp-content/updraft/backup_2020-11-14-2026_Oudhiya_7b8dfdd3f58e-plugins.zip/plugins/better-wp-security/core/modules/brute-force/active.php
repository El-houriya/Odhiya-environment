<?php

require_once( 'class-itsec-brute-force.php' );
$itsec_brute_force = new ITSEC_Brute_Force();
$itsec_brute_force->run();
